#ifndef WT13106_CONNECTION_H
#define WT13106_CONNECTION_H

#include <vector>
#include <cstdint>
#include <string>

/**
 * @brief Class for managing connection and communication with WT13106 device
 * 
 * This class provides an interface for connecting to and communicating
 * with the WT13106 device. The implementation should be based on the
 * device's specific communication protocol (USB, Serial, or Network).
 */
class WT13106Connection {
public:
    /**
     * @brief Constructor
     * @param connectionString Connection string (e.g., COM port, USB VID/PID, IP:Port)
     */
    explicit WT13106Connection(const std::string& connectionString);
    
    /**
     * @brief Destructor - ensures proper disconnection
     */
    ~WT13106Connection();
    
    /**
     * @brief Establish connection to the WT13106 device
     * @return true if connection successful, false otherwise
     */
    bool connect();
    
    /**
     * @brief Disconnect from the WT13106 device
     * @return true if disconnection successful, false otherwise
     */
    bool disconnect();
    
    /**
     * @brief Check if device is currently connected
     * @return true if connected, false otherwise
     */
    bool isConnected() const;
    
    /**
     * @brief Send a command to the device
     * @param command Command data to send
     * @return true if command sent successfully, false otherwise
     */
    bool sendCommand(const std::vector<uint8_t>& command);
    
    /**
     * @brief Receive response from the device
     * @param timeoutMs Timeout in milliseconds (0 = no timeout)
     * @return Response data from device, empty vector on error/timeout
     */
    std::vector<uint8_t> receiveResponse(uint32_t timeoutMs = 1000);
    
    /**
     * @brief Send command and wait for response
     * @param command Command data to send
     * @param timeoutMs Timeout in milliseconds
     * @return Response data from device, empty vector on error/timeout
     */
    std::vector<uint8_t> sendCommandAndReceive(const std::vector<uint8_t>& command, 
                                                uint32_t timeoutMs = 1000);
    
    /**
     * @brief Get last error message
     * @return Error message string
     */
    std::string getLastError() const;

private:
    std::string m_connectionString;
    bool m_isConnected;
    std::string m_lastError;
    
    // Connection handle/interface - implementation specific
    // Examples:
    // void* m_usbHandle;        // For USB connections
    // HANDLE m_serialHandle;    // For Windows serial connections
    // int m_socketFd;           // For network connections
    
    /**
     * @brief Initialize the connection based on connection string
     * @return true if initialization successful
     */
    bool initializeConnection();
    
    /**
     * @brief Clean up connection resources
     */
    void cleanupConnection();
};

#endif // WT13106_CONNECTION_H

